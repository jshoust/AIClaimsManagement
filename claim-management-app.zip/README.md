# Claim Management Application

This is a claim management application built with React and Express.

## Installation

1. Install dependencies:

```
npm install
```

2. Start the development server:

```
npm run dev
```

3. Build for production:

```
npm run build
```

4. Start the production server:

```
npm start
```

